def InsertRecursive(array_terurut,  nilai_sekarang, panjang_sekarang):
    # TODO 1: Implementasikan base case, logika komparasi pengurutan sesuai NIM, 
    # dan pemanggilan rekursi fungsi insert.
    if panjang_sekarang == 0:
        return [nilai_sekarang]
    
    if array_terurut[panjang_sekarang - 1] <= nilai_sekarang:
        return array_terurut + [nilai_sekarang]
    
    return InsertRecursive(array_terurut[: panjang_sekarang - 1], nilai_sekarang, panjang_sekarang - 1) + [array_terurut[panjang_sekarang - 1]]

def RecursiveFilterSort(array_data, panjang_sekarang):
    # TODO 2: Implementasikan base case, pemecahan rekursif, dan filter kondisional 
    # untuk memanggil fungsi InsertRecursive sesuai paritas NIM.
    if panjang_sekarang == 0:
        return []

    hasil = RecursiveFilterSort(array_data, panjang_sekarang - 1)
    nilai = array_data[panjang_sekarang - 1]
    
        # NIM berakhir 3, jadi hanya mengambil angka ganjil
    return InsertRecursive(hasil, nilai, len(hasil)) if nilai % 2 != 0 else hasil

# Ganti Dengan NIM Anda
# Contoh, NIM_MAHASISWA = "71230994" -> nanti outputnya [4, 2, 0] 
NIM_MAHASISWA = "71251213"

if NIM_MAHASISWA != "":
    data_awal = [int(digit) for digit in NIM_MAHASISWA]
    panjang_data = len(data_awal)
    
    hasil_akhir = RecursiveFilterSort(data_awal, panjang_data)

    # TODO 3: cetak hasil akhir sesuai format yang diminta.
    print("===== FILTER & SORT NIM =====")
    print("NIM Mahasiswa  :", NIM_MAHASISWA)
    print("Tipe           : GANJIL (Ascending)")
    print("Data Digit Awal:", data_awal)
    print("Hasil Akhir    :", hasil_akhir)